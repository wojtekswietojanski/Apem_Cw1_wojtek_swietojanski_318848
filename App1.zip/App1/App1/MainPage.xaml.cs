﻿using System;
using Windows.Media.Core;
using Windows.Media.Playback;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace SimpleAudio
{
    public sealed partial class MainPage : Page
    {
        private MediaPlayer mediaPlayer;

        public MainPage()
        {
            this.InitializeComponent();
            mediaPlayer = new MediaPlayer();
        }

        private async void SelectFileButton_Click(object sender, RoutedEventArgs e)
        {
            // Otwórz okno dialogowe wyboru pliku audio
            var picker = new Windows.Storage.Pickers.FileOpenPicker();
            picker.FileTypeFilter.Add(".mp3");
            picker.FileTypeFilter.Add(".wav");
            picker.FileTypeFilter.Add(".wma");

            StorageFile file = await picker.PickSingleFileAsync();

            if (file != null)
            {
                // Ustaw plik audio dla odtwarzacza
                mediaPlayer.Source = MediaSource.CreateFromStorageFile(file);

                // Włącz przyciski Play i Pause
                playButton.IsEnabled = true;
                pauseButton.IsEnabled = true;
            }
        }

        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            // Rozpocznij odtwarzanie
            mediaPlayer.Play();
        }

        private void PauseButton_Click(object sender, RoutedEventArgs e)
        {
            // Zatrzymaj odtwarzanie lub wznow
            if (mediaPlayer.PlaybackSession.PlaybackState == MediaPlaybackState.Playing)
            {
                mediaPlayer.Pause();
            }
            else
            {
                mediaPlayer.Play();
            }
        }
    }
}
